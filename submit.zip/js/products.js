let array_product = [
    { "name": "orange","category":"fruits",'price':"$4:50-#$10"},
    { "name": "mango","category":"fruits",'price':"$4:50-#$10"},
    { "name": "banana","category":"fruits",'price':"$4:50-#$10"},
	{ "name": "onion","category":"vegetables",'price':"$4:50-#$10"},
    { "name": "carot" ,"category":"vegetables",'price':"$4:50-#$10"},
    { "name": "avocardo","category":"vegetables",'price':"$4:50-#$10"},
    { "name": "potato","category":"vegetables",'price':"$4:50-#$10"},
	{ "name": "milk" ,"category":"dairy",'price':"$4:50-#$10"},
    { "name": "eggs","category":"dairy",'price':"$4:50-#$10"},
    { "name": "yogurt","category":"dairy",'price':"$4:50-#$10"},
    { "name": "chicken" ,"category":"meats",'price':"$4:50-#$10"},
    { "name": "bacon" ,"category":"meats",'price':"$4:50-#$10"},
    { "name": "peproni","category":"meats",'price':"$4:50-#$10"},
];


function createProductCard(array_product){
	const card = document.createElement('div');
	card.classList.add('swiper-slide');
	card.classList.add('box');
	const productImage = document.createElement('img');
	productImage.src = array_product.imgUrl;
	
	
	const productTitle = document.createElement('h3');
	productTitle.innerHTML =  array_product.name;


	const productPrice = document.createElement('div');
	productPrice.classList.add('price')
	productPrice.innerHTML = array_product.price;
	

	const stars = document.createElement('div');
	stars.classList.add('stars');
	

		const fas = document.createElement('i');
		fas.classList.add('fas');
	
	
	stars.appendChild(fas);

	let link = document.createElement('a');
	link.title = "my title text";
	link.classList.add('btn')
	link.setAttribute('href', "#");
	link.innerHTML = 'Add to cart'
     
	

	card.appendChild(productImage);
	card.appendChild(productTitle);
	card.appendChild(productPrice);
	card.appendChild(stars);
	card.appendChild(link);

	return card;
}
let x= createProductCard();
document.write(x);